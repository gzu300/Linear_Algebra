This is a project that implements the algorithms into codes as I followed through 'Introduction to Linear Algebra' by Prof. Gilbert Strang and at the same time, practice packaging and coding skills. 

This will be a CLI application. Maybe will be evolved into other forms in the future.

Here is a quick command line usage example:
`calculate projection -A [[1,0],[1,1],[1,2]] -b [6,0,0]`